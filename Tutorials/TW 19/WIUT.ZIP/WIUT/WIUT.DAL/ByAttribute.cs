﻿namespace WIUT.DAL
{
    public enum ByAttribute
    {
        Name,
        Surname,
        DoB,
        Course
    }
}
